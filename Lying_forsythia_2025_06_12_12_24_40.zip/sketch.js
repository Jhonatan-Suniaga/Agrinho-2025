// Variáveis globais para o jogo
let player;
let ambienteAtual = 'campo'; // Pode ser 'campo' ou 'cidade'
let vegetaisColetados = []; // Mantido, mas 'player.inventory' é o principal agora
let caminhoes = [];
let npcsCampo = [];
let npcsCidade = [];
let mapaCampo; // Para futuras implementações de imagem de mapa
let mapaCidade; // Para futuras implementações de imagem de mapa
let vegetaisNoCampo = []; // Adicionada para os vegetais visíveis no campo

let currentDialogue = ""; // Armazena o diálogo atual a ser exibido
let dialogueTimer = 0; // Temporizador para o diálogo
const DIALOGUE_DURATION = 180; // Duração do diálogo em frames (aprox. 3 segundos a 60fps)

// Pré-carregamento de imagens e outros assets (se houver)
function preload() {
  // Exemplo:
  // playerImg = loadImage('assets/player.png');
  // vegetalCenouraImg = loadImage('assets/cenoura.png');
  // vegetalAlfaceImg = loadImage('assets/alface.png');
  // vegetalTomateImg = loadImage('assets/tomate.png');
  // caminhaoImg = loadImage('assets/caminhao.png');
  // mapaCampo = loadImage('assets/mapa_campo.jpg');
  // mapaCidade = loadImage('assets/mapa_cidade.jpg');
}

function setup() {
  createCanvas(800, 600); // Tamanho da tela
  player = new Player();

  // Inicializa vegetais no campo
  for (let i = 0; i < 15; i++) {
    let type = random(['cenoura', 'alface', 'tomate']);
    let x = random(width * 0.1, width * 0.9); // Espalha mais os vegetais
    let y = random(height * 0.5, height * 0.9);
    vegetaisNoCampo.push(new Vegetal(x, y, type));
  }

  // Inicializa caminhões
  caminhoes.push(new Caminhao());
  caminhoes.push(new Caminhao());

  // Inicializa NPCs
  npcsCampo.push(new NPC('campo', "Bem-vindo ao campo, fazendeiro! Colha vegetais para os caminhões."));
  npcsCampo.push(new NPC('campo', "Os caminhões levam os vegetais para a cidade."));
  npcsCidade.push(new NPC('cidade', "A cidade precisa de produtos frescos! Entregue seus vegetais aos caminhões."));
  npcsCidade.push(new NPC('cidade', "O mercado está esperando seus produtos."));
}

function draw() {
  // Desenha o ambiente atual
  if (ambienteAtual === 'campo') {
    background(100, 150, 50); // Cor de fundo para o campo (verde)
    // image(mapaCampo, 0, 0, width, height); // Se usar imagem de mapa
    desenharCampo();
  } else {
    background(150, 150, 150); // Cor de fundo para a cidade (cinza)
    // image(mapaCidade, 0, 0, width, height); // Se usar imagem de mapa
    desenharCidade();
  }

  // Desenha e atualiza outros elementos (vegetais, caminhões, NPCs)
  if (ambienteAtual === 'campo') {
    for (let vegetal of vegetaisNoCampo) {
      vegetal.display();
    }
  }

  for (let caminhao of caminhoes) {
    caminhao.update();
    caminhao.display();
  }

  if (ambienteAtual === 'campo') {
    for (let npc of npcsCampo) {
      npc.display();
    }
  } else {
    for (let npc of npcsCidade) {
      npc.display();
    }
  }

  // Desenha o player (após os elementos do ambiente para que ele fique por cima)
  player.update();
  player.display();

  // Lógica de colisão, interação, etc.
  handleInteractions();

  // Exibe o inventário do jogador
  displayInventory();

  // Exibe o diálogo atual, se houver
  displayDialogue();
}

function keyPressed() {
  // Lógica para mudar de ambiente ao pressionar uma tecla (ex: 'M' para mapa ou teletransporte)
  if (key === 'm' || key === 'M') {
    if (ambienteAtual === 'campo') {
      ambienteAtual = 'cidade';
      player.x = width * 0.1; // Posiciona o player na entrada da cidade
      player.y = height * 0.5;
    } else {
      ambienteAtual = 'campo';
      player.x = width * 0.9; // Posiciona o player na entrada do campo
      player.y = height * 0.5;
    }
  }
  if (key === 'e' || key === 'E') { // Tecla para interação com NPCs e Caminhões
    handleNPCInteraction();
    handleTruckInteraction();
  }
}

// Funções para desenhar o ambiente específico (campo e cidade)
function desenharCampo() {
  // Desenhar elementos do campo: fazendas, árvores, rios, campos de plantio
  fill(139, 69, 19); // Cor da terra
  rect(width * 0.1, height * 0.7, width * 0.3, height * 0.2); // Exemplo de um campo de plantio

  fill(0, 100, 0); // Cor das árvores
  ellipse(width * 0.8, height * 0.3, 80, 80); // Exemplo de uma árvore
  rect(width * 0.79, height * 0.35, 20, 50); // Tronco
}

function desenharCidade() {
  // Desenhar elementos da cidade: prédios, ruas, lojas, praças
  fill(120); // Cor das ruas
  rect(0, height * 0.4, width, height * 0.2);

  fill(80); // Cor dos prédios
  rect(width * 0.1, height * 0.1, 100, 200);
  rect(width * 0.6, height * 0.2, 150, 150);

  // Desenhar pontos de entrega para os caminhões
  fill(255, 0, 0, 150); // Exemplo de ponto de entrega (vermelho semi-transparente)
  for (let caminhao of caminhoes) {
    if (caminhao.destination === 'cidade') { // Desenha o ponto de entrega apenas na cidade
      rect(caminhao.deliveryPoint.x, caminhao.deliveryPoint.y, caminhao.deliveryPoint.width, caminhao.deliveryPoint.height);
    }
  }
}

function handleInteractions() {
  // Lógica de interação com vegetais
  if (ambienteAtual === 'campo') {
    for (let i = vegetaisNoCampo.length - 1; i >= 0; i--) {
      let vegetal = vegetaisNoCampo[i];
      let d = dist(player.x, player.y, vegetal.x, vegetal.y);
      if (d < player.size / 2 + vegetal.size / 2) {
        player.collect(vegetal);
        vegetaisNoCampo.splice(i, 1);
        // Opcional: Adicionar mais vegetais após a coleta para repor o estoque
        if (vegetaisNoCampo.length < 10) { // Garante que sempre haja pelo menos 10 vegetais no campo
          let type = random(['cenoura', 'alface', 'tomate']);
          let x = random(width * 0.1, width * 0.9);
          let y = random(height * 0.5, height * 0.9);
          vegetaisNoCampo.push(new Vegetal(x, y, type));
        }
      }
    }
  }
}

function handleNPCInteraction() {
  let npcsToCheck = (ambienteAtual === 'campo') ? npcsCampo : npcsCidade;
  for (let npc of npcsToCheck) {
    let d = dist(player.x, player.y, npc.x, npc.y);
    if (d < player.size / 2 + npc.size / 2 + 20) { // Aumenta a área de interação
      currentDialogue = npc.dialogue;
      dialogueTimer = DIALOGUE_DURATION; // Reinicia o temporizador do diálogo
      break; // Interage com apenas um NPC por vez
    }
  }
}

function handleTruckInteraction() {
  if (ambienteAtual === 'cidade') { // A interação de entrega acontece na cidade
    for (let caminhao of caminhoes) {
      // Verifica se o player está perto do ponto de entrega do caminhão
      let d = dist(player.x, player.y, caminhao.deliveryPoint.x + caminhao.deliveryPoint.width / 2, caminhao.deliveryPoint.y + caminhao.deliveryPoint.height / 2);
      if (d < player.size / 2 + caminhao.deliveryPoint.width / 2 + 20) { // Aumenta a área de interação
        if (player.inventory.length > 0) {
          caminhao.receiveVegetables(player.inventory);
          player.inventory = []; // Esvazia o inventário do player
          currentDialogue = "Vegetais entregues com sucesso!";
          dialogueTimer = DIALOGUE_DURATION;
        } else {
          currentDialogue = "Seu inventário está vazio. Colete vegetais no campo!";
          dialogueTimer = DIALOGUE_DURATION;
        }
        break;
      }
    }
  }
}

// Função para exibir o inventário do jogador
function displayInventory() {
  let carrotCount = player.inventory.filter(v => v.type === 'cenoura').length;
  let lettuceCount = player.inventory.filter(v => v.type === 'alface').length;
  let tomatoCount = player.inventory.filter(v => v.type === 'tomate').length;

  fill(255, 200); // Fundo semi-transparente para o inventário
  rect(10, 10, 150, 80);
  fill(0);
  textSize(14);
  text('Inventário:', 20, 30);
  text(`Cenouras: ${carrotCount}`, 20, 50);
  text(`Alfaces: ${lettuceCount}`, 20, 65);
  text(`Tomates: ${tomatoCount}`, 20, 80);
}

// Função para exibir o diálogo atual
function displayDialogue() {
  if (dialogueTimer > 0) {
    fill(255, 255, 200, 220); // Balão de fala amarelado semi-transparente
    rect(width / 2 - 150, height - 100, 300, 60, 10); // Retângulo para o balão de fala

    fill(0);
    textSize(16);
    textAlign(CENTER, CENTER);
    text(currentDialogue, width / 2, height - 70);
    textAlign(LEFT, BASELINE); // Volta ao padrão

    dialogueTimer--;
  } else {
    currentDialogue = ""; // Limpa o diálogo quando o tempo acaba
  }
}


// Classes para os objetos do jogo
class Player {
  constructor() {
    this.x = width / 2;
    this.y = height / 2;
    this.size = 30;
    this.speed = 5;
    this.inventory = [];
  }

  update() {
    // Movimento do player
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.speed;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.speed;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.speed;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.speed;
    }

    // Limites da tela (garante que o player esteja sempre visível)
    this.x = constrain(this.x, 0, width - this.size);
    this.y = constrain(this.y, 0, height - this.size);
  }

  display() {
    fill(0, 0, 200); // Cor do player (azul)
    ellipse(this.x, this.y, this.size); // Player como um círculo
    // if (playerImg) { // Se você carregar uma imagem
    //    image(playerImg, this.x - this.size / 2, this.y - this.size / 2, this.size, this.size);
    // }
  }

  collect(vegetal) {
    this.inventory.push(vegetal);
    currentDialogue = `Coletou um(a) ${vegetal.type}!`;
    dialogueTimer = DIALOGUE_DURATION;
  }
}

class Vegetal {
  constructor(x, y, type) {
    this.x = x;
    this.y = y;
    this.type = type; // Ex: 'cenoura', 'alface', 'tomate'
    this.size = 20;
  }

  display() {
    push(); // Isola estilos de desenho
    translate(this.x, this.y);

    if (this.type === 'cenoura') {
      fill(255, 140, 0); // Laranja
      ellipse(0, 0, this.size, this.size * 1.5); // Formato de cenoura
      fill(0, 120, 0); // Verde para as folhas
      triangle(0, -this.size * 0.75, -5, -this.size * 1.2, 5, -this.size * 1.2);
      // if (vegetalCenouraImg) { image(vegetalCenouraImg, -this.size/2, -this.size/2, this.size, this.size); }
    } else if (this.type === 'alface') {
      fill(0, 128, 0); // Verde escuro
      ellipse(0, 0, this.size * 1.5); // Formato de alface
      ellipse(this.size * 0.2, 0, this.size * 1);
      ellipse(-this.size * 0.2, 0, this.size * 1);
      // if (vegetalAlfaceImg) { image(vegetalAlfaceImg, -this.size/2, -this.size/2, this.size, this.size); }
    } else if (this.type === 'tomate') {
      fill(200, 0, 0); // Vermelho
      ellipse(0, 0, this.size * 1.2); // Formato de tomate
      fill(0, 80, 0); // Haste verde
      rectMode(CENTER);
      rect(0, -this.size * 0.7, this.size * 0.4, 5);
      rect(0, -this.size * 0.6, 5, this.size * 0.4);
      // if (vegetalTomateImg) { image(vegetalTomateImg, -this.size/2, -this.size/2, this.size, this.size); }
    }
    pop(); // Restaura estilos de desenho
  }
}

class Caminhao {
  constructor() {
    this.x = random(width);
    this.y = random(height * 0.4, height * 0.6); // Posiciona o caminhão na área da rua
    this.width = 80;
    this.height = 40;
    this.speed = random(2, 4);
    this.carrying = []; // O que o caminhão está transportando
    this.destination = random(['cidade', 'campo']); // Começa com um destino aleatório
    // Ponto de entrega na cidade para o player
    this.deliveryPoint = {
      x: width * 0.8,
      y: height * 0.5,
      width: 50,
      height: 50
    };
  }

  update() {
    // Lógica de movimento do caminhão
    if (this.destination === 'cidade') {
      this.x += this.speed;
      if (this.x > width + this.width / 2) {
        this.x = -this.width / 2; // Volta para o início
        this.destination = 'campo';
        this.carrying = []; // Descarrega na cidade (simulação)
      }
    } else {
      this.x -= this.speed;
      if (this.x < -this.width / 2) {
        this.x = width + this.width / 2;
        this.destination = 'cidade';
        // Carrega produtos no campo (simulação, poderia ser interação com NPCs)
      }
    }
    // Garante que o caminhão fique dentro dos limites visíveis quando não está "viajando"
    this.y = constrain(this.y, 0, height - this.height);
  }

  display() {
    fill(100, 100, 200); // Cor do caminhão
    rect(this.x, this.y, this.width, this.height);
    fill(0);
    ellipse(this.x + 10, this.y + this.height, 15); // Roda 1
    ellipse(this.x + this.width - 10, this.y + this.height, 15); // Roda 2
    // if (caminhaoImg) { image(caminhaoImg, this.x, this.y, this.width, this.height); }
  }

  receiveVegetables(vegetables) {
    this.carrying.push(...vegetables); // Adiciona os vegetais recebidos
    console.log(`Caminhão recebeu ${vegetables.length} vegetais.`);
  }
}

class NPC {
  constructor(environment, dialogue) {
    this.x = random(width * 0.2, width * 0.8); // Posiciona NPCs em áreas mais visíveis
    this.y = random(height * 0.1, height * 0.3);
    if (environment === 'campo') {
      this.y = random(height * 0.1, height * 0.4);
    } else { // cidade
      this.y = random(height * 0.1, height * 0.3);
      this.x = random(width * 0.1, width * 0.8);
    }
    this.size = 25;
    this.environment = environment; // 'campo' ou 'cidade'
    this.dialogue = dialogue; // Diálogo específico
  }

  display() {
    fill(200, 100, 0); // Cor do NPC (laranja/marrom)
    ellipse(this.x, this.y, this.size);
    // Adicionar balão de fala ao interagir ou apenas como parte do display se for um NPC fixo
  }
}